/* ========================================
   RENTIFY - Rent Items Page Logic
   Handles browsing and renting items
   ======================================== */

// Store selected item for rental
let selectedItemForRent = null;
let uploadedIdPhoto = null;
const DELIVERY_CHARGE = 100;

// Initialize rent items page
document.addEventListener('DOMContentLoaded', function() {
    loadAllItems();
    setupSearchAndFilter();
    setupDeliveryOptions();
    setupIdPhotoUpload();
    
    // Check if category was selected from homepage
    const selectedCategory = sessionStorage.getItem('selectedCategory');
    if (selectedCategory) {
        document.getElementById('categoryFilter').value = selectedCategory;
        sessionStorage.removeItem('selectedCategory');
        filterItems();
    }
    
    // Check if search term from navbar
    const searchTerm = sessionStorage.getItem('searchTerm');
    if (searchTerm) {
        document.getElementById('searchInput').value = searchTerm;
        sessionStorage.removeItem('searchTerm');
        filterItems();
    }
});

/* ========================================
   LOAD AND DISPLAY ITEMS
   ======================================== */

// Load all items (including rented ones)
function loadAllItems() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const items = getItems();
    
    // Filter out user's own items, but show ALL other items (available AND rented)
    const allItems = items.filter(item => item.ownerId !== currentUser.id);
    
    displayItems(allItems);
}

// Display items in grid
function displayItems(items) {
    const container = document.getElementById('itemsContainer');
    const noItemsMsg = document.getElementById('noItemsMessage');
    
    if (items.length === 0) {
        container.innerHTML = '';
        noItemsMsg.classList.remove('d-none');
        return;
    }
    
    noItemsMsg.classList.add('d-none');
    
    // Sort by date (newest first)
    items.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Generate HTML for items
    container.innerHTML = items.map(item => {
        const isRented = item.status === 'rented';
        const statusBadge = isRented 
            ? '<span class="badge bg-warning text-dark">On Rent</span>'
            : '<span class="badge status-available">Available</span>';
        const rentButton = isRented
            ? '<button class="btn btn-secondary w-100" disabled><i class="bi bi-lock"></i> Currently Rented</button>'
            : `<button class="btn btn-primary w-100" onclick="showRentModal('${item.id}')"><i class="bi bi-cart-plus"></i> Rent Now</button>`;
        
        return `
        <div class="col-md-6 col-lg-4">
            <div class="card item-card h-100 ${isRented ? 'opacity-75' : ''}">
                <img src="${item.image}" class="card-img-top" alt="${item.name}" 
                     onerror="this.src='https://via.placeholder.com/400x200?text=No+Image'">
                <div class="card-body">
                    <span class="item-category">${item.category}</span>
                    <h5 class="card-title mt-2">${item.name}</h5>
                    <p class="card-text text-muted">${item.description}</p>
                    <div class="mb-2">
                        <small class="text-muted">
                            <i class="bi bi-person"></i> Owner: ${item.ownerName}
                        </small>
                    </div>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="item-price">${formatCurrency(item.price)}/day</span>
                        ${statusBadge}
                    </div>
                    <div class="mb-3">
                        <small class="text-success">
                            <i class="bi bi-shield-check"></i> Deposit: ${formatCurrency(item.securityDeposit || 0)}
                        </small>
                    </div>
                    ${rentButton}
                </div>
            </div>
        </div>
    `;
    }).join('');
}

/* ========================================
   DELIVERY OPTIONS HANDLING
   ======================================== */

function setupDeliveryOptions() {
    const selfPickup = document.getElementById('selfPickup');
    const homeDelivery = document.getElementById('homeDelivery');
    
    if (selfPickup) {
        selfPickup.addEventListener('change', function() {
            if (this.checked) {
                document.getElementById('ownerAddressSection').style.display = 'block';
                document.getElementById('deliveryAddressSection').style.display = 'none';
                document.getElementById('deliveryChargeRow').style.display = 'none';
                updatePaymentSummary();
            }
        });
    }
    
    if (homeDelivery) {
        homeDelivery.addEventListener('change', function() {
            if (this.checked) {
                document.getElementById('ownerAddressSection').style.display = 'none';
                document.getElementById('deliveryAddressSection').style.display = 'block';
                document.getElementById('deliveryChargeRow').style.display = 'flex';
                updatePaymentSummary();
            }
        });
    }
}

function updatePaymentSummary() {
    if (!selectedItemForRent) return;
    
    const homeDelivery = document.getElementById('homeDelivery');
    const deliveryCharge = homeDelivery && homeDelivery.checked ? DELIVERY_CHARGE : 0;
    
    const price = selectedItemForRent.price;
    const deposit = selectedItemForRent.securityDeposit || 0;
    const total = price + deposit + deliveryCharge;
    
    document.getElementById('summaryDeliveryCharge').textContent = formatCurrency(deliveryCharge);
    document.getElementById('summaryTotal').textContent = formatCurrency(total);
}

/* ========================================
   ID PHOTO UPLOAD HANDLING
   ======================================== */

function setupIdPhotoUpload() {
    const idPhotoInput = document.getElementById('rentIdPhoto');
    if (idPhotoInput) {
        idPhotoInput.addEventListener('change', handleIdPhotoUpload);
    }
}

function handleIdPhotoUpload(e) {
    const file = e.target.files[0];
    
    if (!file) {
        uploadedIdPhoto = null;
        document.getElementById('idPhotoPreview').classList.add('d-none');
        return;
    }
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
        alert('Please select a valid image file');
        e.target.value = '';
        return;
    }
    
    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
        alert('Image size should be less than 2MB');
        e.target.value = '';
        return;
    }
    
    // Read file as Base64
    const reader = new FileReader();
    
    reader.onload = function(event) {
        uploadedIdPhoto = event.target.result;
        
        // Show preview
        const previewImg = document.getElementById('idPreviewImg');
        const idPhotoPreview = document.getElementById('idPhotoPreview');
        
        previewImg.src = uploadedIdPhoto;
        idPhotoPreview.classList.remove('d-none');
    };
    
    reader.onerror = function() {
        alert('Error reading file. Please try again.');
        uploadedIdPhoto = null;
    };
    
    reader.readAsDataURL(file);
}

/* ========================================
   SEARCH AND FILTER FUNCTIONALITY
   ======================================== */

// Setup search and filter listeners
function setupSearchAndFilter() {
    const searchInput = document.getElementById('searchInput');
    
    // Real-time search
    searchInput.addEventListener('input', function() {
        filterItems();
    });
    
    // Enter key search
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            filterItems();
        }
    });
}

// Filter items based on search and category
function filterItems() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const searchTerm = document.getElementById('searchInput').value.toLowerCase().trim();
    const categoryFilter = document.getElementById('categoryFilter').value;
    
    let items = getItems();
    
    // Filter out user's own items, but show ALL other items (available AND rented)
    items = items.filter(item => item.ownerId !== currentUser.id);
    
    // Apply search filter
    if (searchTerm) {
        items = items.filter(item => 
            item.name.toLowerCase().includes(searchTerm) ||
            item.description.toLowerCase().includes(searchTerm) ||
            item.category.toLowerCase().includes(searchTerm)
        );
    }
    
    // Apply category filter
    if (categoryFilter) {
        items = items.filter(item => item.category === categoryFilter);
    }
    
    displayItems(items);
}

/* ========================================
   RENT ITEM FUNCTIONALITY
   ======================================== */

// Show rent confirmation modal
function showRentModal(itemId) {
    const items = getItems();
    const item = items.find(i => i.id === itemId);
    
    if (!item) {
        alert('Item not found');
        return;
    }
    
    if (item.status === 'rented') {
        alert('This item is currently rented by someone else');
        return;
    }
    
    // Store selected item
    selectedItemForRent = item;
    
    // Update modal content
    const modalBody = document.getElementById('rentItemDetails');
    modalBody.innerHTML = `
        <div class="card">
            <img src="${item.image}" class="card-img-top" alt="${item.name}"
                 onerror="this.src='https://via.placeholder.com/400x200?text=No+Image'">
            <div class="card-body">
                <h5 class="card-title">${item.name}</h5>
                <p class="card-text">${item.description}</p>
                <p class="mb-1"><strong>Category:</strong> ${item.category}</p>
                <p class="mb-1"><strong>Price:</strong> ${formatCurrency(item.price)} per day</p>
                <p class="mb-1"><strong>Security Deposit:</strong> <span class="text-success">${formatCurrency(item.securityDeposit || 0)} (Refundable)</span></p>
                <p class="mb-1"><strong>Owner:</strong> ${item.ownerName}</p>
                <p class="mb-0"><strong>Contact:</strong> ${item.ownerPhone}</p>
            </div>
        </div>
    `;
    
    // Update deposit info
    const depositAmount = item.securityDeposit || 0;
    document.getElementById('depositAmount').textContent = formatCurrency(depositAmount);
    document.getElementById('deliveryCharges').textContent = DELIVERY_CHARGE;
    
    // Show owner's address
    const users = getUsers();
    const owner = users.find(u => u.id === item.ownerId);
    if (owner && owner.address) {
        document.getElementById('ownerAddress').textContent = owner.address;
    } else {
        document.getElementById('ownerAddress').textContent = 'Contact owner for address';
    }
    
    // Update payment summary
    document.getElementById('summaryPrice').textContent = formatCurrency(item.price);
    document.getElementById('summaryDeposit').textContent = formatCurrency(depositAmount);
    document.getElementById('summaryDeliveryCharge').textContent = formatCurrency(0);
    document.getElementById('summaryTotal').textContent = formatCurrency(item.price + depositAmount);
    
    // Reset delivery options
    document.getElementById('selfPickup').checked = true;
    document.getElementById('ownerAddressSection').style.display = 'block';
    document.getElementById('deliveryAddressSection').style.display = 'none';
    document.getElementById('deliveryChargeRow').style.display = 'none';
    
    // Pre-fill user's address if available
    const currentUser = getCurrentUser();
    if (currentUser && currentUser.address) {
        document.getElementById('rentAddress').value = currentUser.address;
    }
    if (currentUser && currentUser.phone) {
        document.getElementById('rentPhone').value = currentUser.phone;
    }
    
    // Reset ID photo
    uploadedIdPhoto = null;
    document.getElementById('idPhotoPreview').classList.add('d-none');
    document.getElementById('rentIdPhoto').value = '';
    
    // Show modal
    const rentModal = new bootstrap.Modal(document.getElementById('rentModal'));
    rentModal.show();
}

// Confirm rental
function confirmRent() {
    if (!selectedItemForRent) {
        alert('No item selected');
        return;
    }
    
    const currentUser = getCurrentUser();
    if (!currentUser) {
        alert('Please login to rent items');
        return;
    }
    
    // Get ID verification details
    const idType = document.getElementById('rentIdType').value;
    const idNumber = document.getElementById('rentIdNumber').value.trim();
    
    // Check ID photo upload
    if (!uploadedIdPhoto) {
        alert('Please upload your ID photo. It is compulsory for security.');
        return;
    }
    
    // Get delivery option
    const deliveryOption = document.querySelector('input[name="deliveryOption"]:checked').value;
    const deliveryCharge = deliveryOption === 'delivery' ? DELIVERY_CHARGE : 0;
    
    // Get delivery address details (only if home delivery selected)
    let deliveryAddress = '';
    let deliveryCity = '';
    let deliveryPincode = '';
    let deliveryPhone = '';
    
    if (deliveryOption === 'delivery') {
        deliveryAddress = document.getElementById('rentAddress').value.trim();
        deliveryCity = document.getElementById('rentCity').value.trim();
        deliveryPincode = document.getElementById('rentPincode').value.trim();
        deliveryPhone = document.getElementById('rentPhone').value.trim();
        
        // Validate delivery address fields
        if (!deliveryAddress || !deliveryCity || !deliveryPincode || !deliveryPhone) {
            alert('Please fill in all delivery address fields');
            return;
        }
        
        if (deliveryPincode.length !== 6 || !/^\d+$/.test(deliveryPincode)) {
            alert('Please enter a valid 6-digit pincode');
            return;
        }
        
        if (deliveryPhone.length !== 10 || !/^\d+$/.test(deliveryPhone)) {
            alert('Please enter a valid 10-digit phone number');
            return;
        }
    }
    
    // Check terms agreement
    const agreeTerms = document.getElementById('agreeTerms').checked;
    
    // Validate ID fields
    if (!idType || !idNumber) {
        alert('Please provide your ID details for verification');
        return;
    }
    
    if (idNumber.length < 5) {
        alert('Please enter a valid ID number');
        return;
    }
    
    if (!agreeTerms) {
        alert('Please agree to the terms and conditions');
        return;
    }
    
    // Check if item is still available
    const items = getItems();
    const item = items.find(i => i.id === selectedItemForRent.id);
    
    if (!item || item.status !== 'available') {
        alert('This item is no longer available');
        return;
    }
    
    // Create rental record with all security details
    const rental = {
        id: generateId(),
        itemId: item.id,
        itemName: item.name,
        itemCategory: item.category,
        itemDescription: item.description,
        itemImage: item.image,
        renterId: currentUser.id,
        renterName: currentUser.name,
        ownerId: item.ownerId,
        ownerName: item.ownerName,
        ownerPhone: item.ownerPhone,
        price: item.price,
        securityDeposit: item.securityDeposit || 0,
        depositPaid: true,
        depositRefunded: false,
        rentDate: new Date().toISOString(),
        // ID Verification
        renterIdType: idType,
        renterIdNumber: idNumber,
        renterIdPhoto: uploadedIdPhoto,
        // Delivery Options
        deliveryOption: deliveryOption,
        deliveryCharge: deliveryCharge,
        deliveryAddress: deliveryAddress,
        deliveryCity: deliveryCity,
        deliveryPincode: deliveryPincode,
        deliveryPhone: deliveryPhone
    };
    
    // Save rental
    const rentals = getRentals();
    rentals.push(rental);
    saveRentals(rentals);
    
    // Update item status
    const itemIndex = items.findIndex(i => i.id === item.id);
    items[itemIndex].status = 'rented';
    saveItems(items);
    
    // Close modal
    const rentModal = bootstrap.Modal.getInstance(document.getElementById('rentModal'));
    rentModal.hide();
    
    // Clear form
    document.getElementById('rentSecurityForm').reset();
    uploadedIdPhoto = null;
    
    // Show success message
    const deliveryMsg = deliveryOption === 'delivery' 
        ? `\nDelivery Charge: ${formatCurrency(deliveryCharge)}\nItem will be delivered to your address.`
        : '\nPlease pick up the item from owner\'s address.';
    
    simulateAsync(() => {
        alert(`Item rented successfully!\n\nSecurity Deposit: ${formatCurrency(item.securityDeposit || 0)}\nThis deposit will be refunded when you return the item in good condition.${deliveryMsg}\n\nThe owner will contact you soon.`);
        loadAllItems();
        selectedItemForRent = null;
    }, 300);
}
