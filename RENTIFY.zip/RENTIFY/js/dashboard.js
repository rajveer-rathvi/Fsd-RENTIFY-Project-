/* ========================================
   RENTIFY - Dashboard Logic
   Handles item listing and user dashboard
   ======================================== */

// Initialize dashboard on page load
document.addEventListener('DOMContentLoaded', function() {
    loadUserProfile();
    loadStatistics();
    loadMyItems();
    loadRentedItems();
    setupDashboardListeners();
});

/* ========================================
   DASHBOARD INITIALIZATION
   ======================================== */

// Setup event listeners for dashboard
function setupDashboardListeners() {
    const listItemForm = document.getElementById('listItemForm');
    if (listItemForm) {
        listItemForm.addEventListener('submit', handleListItem);
    }
    
    // Image upload listener
    const imageFileInput = document.getElementById('itemImageFile');
    if (imageFileInput) {
        imageFileInput.addEventListener('change', handleImageUpload);
    }
    
    // Tab change listeners
    const tabs = document.querySelectorAll('#dashboardTabs button');
    tabs.forEach(tab => {
        tab.addEventListener('shown.bs.tab', function(e) {
            const target = e.target.getAttribute('data-bs-target');
            if (target === '#my-items') {
                loadMyItems();
            } else if (target === '#rented') {
                loadRentedItems();
            }
        });
    });
}

/* ========================================
   IMAGE UPLOAD HANDLING
   ======================================== */

// Store uploaded image as Base64
let uploadedImageData = null;

// Handle image file upload
function handleImageUpload(e) {
    const file = e.target.files[0];
    
    if (!file) {
        uploadedImageData = null;
        document.getElementById('imagePreview').classList.add('d-none');
        return;
    }
    
    // Validate file type
    if (!file.type.startsWith('image/')) {
        alert('Please select a valid image file');
        e.target.value = '';
        return;
    }
    
    // Validate file size (max 2MB)
    if (file.size > 2 * 1024 * 1024) {
        alert('Image size should be less than 2MB');
        e.target.value = '';
        return;
    }
    
    // Read file as Base64
    const reader = new FileReader();
    
    reader.onload = function(event) {
        uploadedImageData = event.target.result;
        
        // Show preview
        const previewImg = document.getElementById('previewImg');
        const imagePreview = document.getElementById('imagePreview');
        
        previewImg.src = uploadedImageData;
        imagePreview.classList.remove('d-none');
        
        console.log('Image uploaded successfully!');
    };
    
    reader.onerror = function() {
        alert('Error reading file. Please try again.');
        uploadedImageData = null;
    };
    
    reader.readAsDataURL(file);
}

/* ========================================
   USER PROFILE SECTION
   ======================================== */

// Load user profile information
function loadUserProfile() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    document.getElementById('profileName').textContent = currentUser.name;
    document.getElementById('profileEmail').textContent = currentUser.email;
    document.getElementById('profilePhone').textContent = currentUser.phone;
}

/* ========================================
   STATISTICS SECTION
   ======================================== */

// Load and display statistics
function loadStatistics() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const items = getItems();
    const rentals = getRentals();
    
    // Calculate statistics
    const myItems = items.filter(item => item.ownerId === currentUser.id);
    const myRentals = rentals.filter(rental => rental.renterId === currentUser.id);
    const availableItems = myItems.filter(item => item.status === 'available');
    
    // Update UI
    document.getElementById('totalListedItems').textContent = myItems.length;
    document.getElementById('totalRentedItems').textContent = myRentals.length;
    document.getElementById('availableItems').textContent = availableItems.length;
    
    // Add animation
    animateNumber('totalListedItems', myItems.length);
    animateNumber('totalRentedItems', myRentals.length);
    animateNumber('availableItems', availableItems.length);
}

// Animate number counting
function animateNumber(elementId, targetNumber) {
    const element = document.getElementById(elementId);
    let current = 0;
    const increment = targetNumber / 20;
    const timer = setInterval(() => {
        current += increment;
        if (current >= targetNumber) {
            element.textContent = targetNumber;
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current);
        }
    }, 50);
}

/* ========================================
   LIST NEW ITEM SECTION
   ======================================== */

// Handle listing a new item
function handleListItem(e) {
    e.preventDefault();
    
    const currentUser = getCurrentUser();
    if (!currentUser) {
        alert('Please login to list items');
        return;
    }
    
    // Get form values
    const name = document.getElementById('itemName').value.trim();
    const category = document.getElementById('itemCategory').value;
    const price = parseFloat(document.getElementById('itemPrice').value);
    const deposit = parseFloat(document.getElementById('itemDeposit').value);
    const imageUrl = document.getElementById('itemImage').value.trim();
    const description = document.getElementById('itemDescription').value.trim();
    
    // Determine which image to use (uploaded file or URL)
    let finalImage = '';
    
    if (uploadedImageData) {
        // Use uploaded image (Base64)
        finalImage = uploadedImageData;
    } else if (imageUrl) {
        // Use image URL
        finalImage = imageUrl;
    } else {
        alert('Please upload an image or provide an image URL');
        return;
    }
    
    // Validation
    if (!name || !category || !price || !description) {
        alert('Please fill in all fields');
        return;
    }
    
    if (price < 1) {
        alert('Price must be at least ₹1');
        return;
    }
    
    if (deposit < 0) {
        alert('Security deposit cannot be negative');
        return;
    }
    
    // Create new item object
    const newItem = {
        id: generateId(),
        name: name,
        category: category,
        price: price,
        securityDeposit: deposit,
        image: finalImage,
        description: description,
        ownerId: currentUser.id,
        ownerName: currentUser.name,
        ownerPhone: currentUser.phone,
        status: 'available',
        createdAt: new Date().toISOString()
    };
    
    // Save item
    const items = getItems();
    items.push(newItem);
    saveItems(items);
    
    // Show success message
    showSuccess('listItemSuccess', 'Item listed successfully with security deposit!');
    
    // Reset form and reload data
    simulateAsync(() => {
        document.getElementById('listItemForm').reset();
        document.getElementById('imagePreview').classList.add('d-none');
        uploadedImageData = null;
        hideElement('listItemSuccess');
        loadStatistics();
        loadMyItems();
    }, 1500);
}

/* ========================================
   MY LISTED ITEMS SECTION
   ======================================== */

// Load user's listed items
function loadMyItems() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const items = getItems();
    const myItems = items.filter(item => item.ownerId === currentUser.id);
    
    const container = document.getElementById('myItemsContainer');
    const noItemsMsg = document.getElementById('noMyItems');
    
    if (myItems.length === 0) {
        container.innerHTML = '';
        noItemsMsg.classList.remove('d-none');
        return;
    }
    
    noItemsMsg.classList.add('d-none');
    
    // Sort by date (newest first)
    myItems.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Generate HTML for items
    container.innerHTML = myItems.map(item => `
        <div class="col-md-6 col-lg-4">
            <div class="card item-card h-100">
                <img src="${item.image}" class="card-img-top" alt="${item.name}" onerror="this.src='https://via.placeholder.com/400x200?text=No+Image'">
                <div class="card-body">
                    <span class="item-category">${item.category}</span>
                    <h5 class="card-title mt-2">${item.name}</h5>
                    <p class="card-text text-muted">${item.description}</p>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="item-price">${formatCurrency(item.price)}/day</span>
                        <span class="badge ${item.status === 'available' ? 'status-available' : 'status-rented'}">
                            ${item.status === 'available' ? 'Available' : 'Rented'}
                        </span>
                    </div>
                    <div class="mb-2">
                        <small class="text-success">
                            <i class="bi bi-shield-check"></i> Security Deposit: ${formatCurrency(item.securityDeposit || 0)}
                        </small>
                    </div>
                    <small class="text-muted d-block mt-2">Listed on ${formatDate(item.createdAt)}</small>
                    <button class="btn btn-danger btn-sm mt-3 w-100" onclick="deleteItem('${item.id}')">
                        <i class="bi bi-trash"></i> Delete Item
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Delete an item
function deleteItem(itemId) {
    if (!confirm('Are you sure you want to delete this item?')) {
        return;
    }
    
    const items = getItems();
    const updatedItems = items.filter(item => item.id !== itemId);
    saveItems(updatedItems);
    
    // Also remove any rentals for this item
    const rentals = getRentals();
    const updatedRentals = rentals.filter(rental => rental.itemId !== itemId);
    saveRentals(updatedRentals);
    
    // Reload data
    loadStatistics();
    loadMyItems();
    
    // Show notification
    alert('Item deleted successfully!');
}

/* ========================================
   MY RENTALS SECTION
   ======================================== */

// Load items rented by user
function loadRentedItems() {
    const currentUser = getCurrentUser();
    if (!currentUser) return;
    
    const rentals = getRentals();
    const myRentals = rentals.filter(rental => rental.renterId === currentUser.id);
    
    const container = document.getElementById('rentedItemsContainer');
    const noRentalsMsg = document.getElementById('noRentedItems');
    
    if (myRentals.length === 0) {
        container.innerHTML = '';
        noRentalsMsg.classList.remove('d-none');
        return;
    }
    
    noRentalsMsg.classList.add('d-none');
    
    // Sort by date (newest first)
    myRentals.sort((a, b) => new Date(b.rentDate) - new Date(a.rentDate));
    
    // Generate HTML for rentals
    container.innerHTML = myRentals.map(rental => `
        <div class="col-md-6 col-lg-4">
            <div class="card item-card h-100">
                <img src="${rental.itemImage || 'https://via.placeholder.com/400x200?text=Rented+Item'}" 
                     class="card-img-top" alt="${rental.itemName}"
                     onerror="this.src='https://via.placeholder.com/400x200?text=No+Image'">
                <div class="card-body">
                    <span class="item-category">${rental.itemCategory || 'Other'}</span>
                    <h5 class="card-title mt-2">${rental.itemName}</h5>
                    <p class="card-text text-muted">${rental.itemDescription || 'No description available'}</p>
                    <div class="mb-2">
                        <small class="text-muted">
                            <i class="bi bi-person"></i> Owner: ${rental.ownerName}
                        </small>
                    </div>
                    <div class="mb-2">
                        <small class="text-muted">
                            <i class="bi bi-telephone"></i> ${rental.ownerPhone}
                        </small>
                    </div>
                    ${rental.deliveryAddress ? `
                    <div class="mb-2">
                        <small class="text-muted">
                            <i class="bi bi-geo-alt"></i> <strong>Delivery:</strong><br>
                            ${rental.deliveryAddress}, ${rental.deliveryCity || ''} - ${rental.deliveryPincode || ''}<br>
                            <i class="bi bi-phone"></i> ${rental.deliveryPhone || ''}
                        </small>
                    </div>
                    ` : ''}
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <span class="item-price">${formatCurrency(rental.price)}/day</span>
                        <span class="badge bg-warning text-dark">Rented</span>
                    </div>
                    ${rental.securityDeposit ? `
                    <div class="alert alert-success py-2 mb-2">
                        <small>
                            <i class="bi bi-shield-check"></i> <strong>Security Deposit:</strong> ${formatCurrency(rental.securityDeposit)}<br>
                            <span class="text-muted">Status: ${rental.depositRefunded ? 'Refunded ✓' : 'Will be refunded on return'}</span>
                        </small>
                    </div>
                    ` : ''}
                    <small class="text-muted d-block mt-2">Rented on ${formatDate(rental.rentDate)}</small>
                    <button class="btn btn-danger btn-sm mt-3 w-100" onclick="returnItem('${rental.id}', '${rental.itemId}')">
                        <i class="bi bi-arrow-return-left"></i> Return Item & Get Deposit Back
                    </button>
                </div>
            </div>
        </div>
    `).join('');
}

// Return a rented item
function returnItem(rentalId, itemId) {
    const rentals = getRentals();
    const rental = rentals.find(r => r.id === rentalId);
    
    if (!rental) {
        alert('Rental not found');
        return;
    }
    
    const depositAmount = rental.securityDeposit || 0;
    const confirmMessage = depositAmount > 0 
        ? `Are you sure you want to return this item?\n\nYour security deposit of ${formatCurrency(depositAmount)} will be refunded.`
        : 'Are you sure you want to return this item?';
    
    if (!confirm(confirmMessage)) {
        return;
    }
    
    // Remove rental
    const updatedRentals = rentals.filter(rental => rental.id !== rentalId);
    saveRentals(updatedRentals);
    
    // Update item status to available
    const items = getItems();
    const itemIndex = items.findIndex(item => item.id === itemId);
    if (itemIndex !== -1) {
        items[itemIndex].status = 'available';
        saveItems(items);
    }
    
    // Reload data
    loadStatistics();
    loadRentedItems();
    
    // Show notification with deposit refund info
    const successMessage = depositAmount > 0
        ? `Item returned successfully!\n\nSecurity deposit of ${formatCurrency(depositAmount)} has been refunded.`
        : 'Item returned successfully!';
    
    alert(successMessage);
}
