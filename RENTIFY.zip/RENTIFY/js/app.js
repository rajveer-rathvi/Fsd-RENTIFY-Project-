/* ========================================
   RENTIFY - Main Application Logic
   Full Stack Development Project
   LocalStorage-based User Management
   ======================================== */

/* ========================================
   UNIT 8: Core JavaScript Concepts & Functions
   ======================================== */

// Initialize application on page load
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    checkAuthStatus();
});

/* ========================================
   UNIT 10: Modern JavaScript - Async Simulation
   ======================================== */

// Simulate async operation using Promise
function simulateAsync(callback, delay = 1000) {
    return new Promise((resolve) => {
        setTimeout(() => {
            callback();
            resolve();
        }, delay);
    });
}

/* ========================================
   LOCALSTORAGE DATA STRUCTURE
   
   Users Array: [
       {
           id: "unique-id",
           name: "John Doe",
           email: "john@example.com",
           password: "hashed-password",
           phone: "1234567890",
           createdAt: "timestamp"
       }
   ]
   
   Items Array: [
       {
           id: "unique-id",
           name: "Camera",
           category: "Electronics",
           price: 500,
           description: "Professional DSLR",
           image: "url",
           ownerId: "user-id",
           ownerName: "John Doe",
           status: "available/rented",
           createdAt: "timestamp"
       }
   ]
   
   Rentals Array: [
       {
           id: "unique-id",
           itemId: "item-id",
           itemName: "Camera",
           renterId: "user-id",
           renterName: "Jane Doe",
           ownerId: "owner-id",
           rentDate: "timestamp",
           price: 500
       }
   ]
   ======================================== */

/* ========================================
   UNIT 9: DOM Manipulation & Events
   ======================================== */

// Initialize the application
function initializeApp() {
    // Initialize LocalStorage if empty
    if (!localStorage.getItem('rentify_users')) {
        localStorage.setItem('rentify_users', JSON.stringify([]));
    }
    if (!localStorage.getItem('rentify_items')) {
        localStorage.setItem('rentify_items', JSON.stringify([]));
    }
    if (!localStorage.getItem('rentify_rentals')) {
        localStorage.setItem('rentify_rentals', JSON.stringify([]));
    }
    
    // Setup event listeners for forms
    setupEventListeners();
}

// Setup all event listeners
function setupEventListeners() {
    // Login form
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.addEventListener('submit', handleLogin);
    }
    
    // Register form
    const registerForm = document.getElementById('registerForm');
    if (registerForm) {
        registerForm.addEventListener('submit', handleRegister);
    }
}

/* ========================================
   UNIT 10: Form Handling & Validation
   ======================================== */

// Handle user registration
function handleRegister(e) {
    e.preventDefault();
    
    // Get form values
    const name = document.getElementById('registerName').value.trim();
    const email = document.getElementById('registerEmail').value.trim().toLowerCase();
    const password = document.getElementById('registerPassword').value;
    const phone = document.getElementById('registerPhone').value.trim();
    const address = document.getElementById('registerAddress').value.trim();
    
    // Validation
    if (name.length < 2) {
        showError('registerError', 'Name must be at least 2 characters');
        return;
    }
    
    if (!isValidEmail(email)) {
        showError('registerError', 'Please enter a valid email');
        return;
    }
    
    if (password.length < 6) {
        showError('registerError', 'Password must be at least 6 characters');
        return;
    }
    
    if (!isValidPhone(phone)) {
        showError('registerError', 'Please enter a valid 10-digit phone number');
        return;
    }
    
    if (address.length < 10) {
        showError('registerError', 'Please enter a complete address');
        return;
    }
    
    // Check if user already exists
    const users = getUsers();
    const existingUser = users.find(u => u.email === email);
    
    if (existingUser) {
        showError('registerError', 'Email already registered. Please login.');
        return;
    }
    
    // Create new user object
    const newUser = {
        id: generateId(),
        name: name,
        email: email,
        password: btoa(password), // Simple encoding (not secure for production)
        phone: phone,
        address: address,
        createdAt: new Date().toISOString()
    };
    
    // Save user
    users.push(newUser);
    localStorage.setItem('rentify_users', JSON.stringify(users));
    
    // Show success message
    showSuccess('registerSuccess', 'Registration successful! Please login.');
    
    // Reset form after delay
    simulateAsync(() => {
        document.getElementById('registerForm').reset();
        hideElement('registerError');
        hideElement('registerSuccess');
        // Close modal and open login modal
        const registerModal = bootstrap.Modal.getInstance(document.getElementById('registerModal'));
        registerModal.hide();
        const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
    }, 1500);
}

// Handle user login
function handleLogin(e) {
    e.preventDefault();
    
    const email = document.getElementById('loginEmail').value.trim().toLowerCase();
    const password = document.getElementById('loginPassword').value;
    
    // Validation
    if (!email || !password) {
        showError('loginError', 'Please fill in all fields');
        return;
    }
    
    // Find user
    const users = getUsers();
    const user = users.find(u => u.email === email && u.password === btoa(password));
    
    if (!user) {
        showError('loginError', 'Invalid email or password');
        return;
    }
    
    // Save current user session
    localStorage.setItem('rentify_currentUser', JSON.stringify(user));
    
    // Simulate async login
    simulateAsync(() => {
        // Close modal
        const loginModal = bootstrap.Modal.getInstance(document.getElementById('loginModal'));
        loginModal.hide();
        
        // Update UI
        updateAuthUI();
        
        // Redirect to dashboard
        window.location.href = 'dashboard.html';
    }, 500);
}

// Logout function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        localStorage.removeItem('rentify_currentUser');
        window.location.href = 'index.html';
    }
}

/* ========================================
   AUTHENTICATION & SESSION MANAGEMENT
   ======================================== */

// Check if user is logged in
function checkAuthStatus() {
    const currentUser = getCurrentUser();
    
    // Update navigation based on auth status
    updateAuthUI();
    
    // Protect dashboard and rent pages
    const protectedPages = ['dashboard.html', 'rent-items.html'];
    const currentPage = window.location.pathname.split('/').pop();
    
    if (protectedPages.includes(currentPage) && !currentUser) {
        alert('Please login to access this page');
        window.location.href = 'index.html';
    }
}

// Update UI based on authentication status
function updateAuthUI() {
    const currentUser = getCurrentUser();
    
    const loginNav = document.getElementById('loginNav');
    const registerNav = document.getElementById('registerNav');
    const userNav = document.getElementById('userNav');
    const logoutNav = document.getElementById('logoutNav');
    const dashboardNav = document.getElementById('dashboardNav');
    const rentItemsNav = document.getElementById('rentItemsNav');
    const navSearchBar = document.getElementById('navSearchBar');
    const usernameDisplay = document.getElementById('usernameDisplay');
    
    if (currentUser) {
        // User is logged in
        if (loginNav) loginNav.style.display = 'none';
        if (registerNav) registerNav.style.display = 'none';
        if (userNav) userNav.style.display = 'block';
        if (logoutNav) logoutNav.style.display = 'block';
        if (dashboardNav) dashboardNav.style.display = 'block';
        if (rentItemsNav) rentItemsNav.style.display = 'block';
        if (navSearchBar) navSearchBar.style.display = 'block';
        if (usernameDisplay) usernameDisplay.textContent = currentUser.name;
    } else {
        // User is not logged in
        if (loginNav) loginNav.style.display = 'block';
        if (registerNav) registerNav.style.display = 'block';
        if (userNav) userNav.style.display = 'none';
        if (logoutNav) logoutNav.style.display = 'none';
        if (dashboardNav) dashboardNav.style.display = 'none';
        if (rentItemsNav) rentItemsNav.style.display = 'none';
        if (navSearchBar) navSearchBar.style.display = 'none';
    }
}

/* ========================================
   NAVBAR SEARCH FUNCTIONALITY
   ======================================== */

function searchFromNav(e) {
    e.preventDefault();
    const searchTerm = document.getElementById('navSearchInput').value.trim();
    if (searchTerm) {
        sessionStorage.setItem('searchTerm', searchTerm);
        window.location.href = 'rent-items.html';
    }
}

/* ========================================
   LOCALSTORAGE CRUD OPERATIONS
   ======================================== */

// Get all users
function getUsers() {
    return JSON.parse(localStorage.getItem('rentify_users') || '[]');
}

// Get current logged-in user
function getCurrentUser() {
    return JSON.parse(localStorage.getItem('rentify_currentUser') || 'null');
}

// Get all items
function getItems() {
    return JSON.parse(localStorage.getItem('rentify_items') || '[]');
}

// Get all rentals
function getRentals() {
    return JSON.parse(localStorage.getItem('rentify_rentals') || '[]');
}

// Save items to localStorage
function saveItems(items) {
    localStorage.setItem('rentify_items', JSON.stringify(items));
}

// Save rentals to localStorage
function saveRentals(rentals) {
    localStorage.setItem('rentify_rentals', JSON.stringify(rentals));
}

/* ========================================
   UTILITY FUNCTIONS
   ======================================== */

// Generate unique ID
function generateId() {
    return 'id_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Email validation
function isValidEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

// Phone validation
function isValidPhone(phone) {
    const phoneRegex = /^[0-9]{10}$/;
    return phoneRegex.test(phone);
}

// Show error message
function showError(elementId, message) {
    const errorElement = document.getElementById(elementId);
    if (errorElement) {
        errorElement.textContent = message;
        errorElement.classList.remove('d-none');
    }
}

// Show success message
function showSuccess(elementId, message) {
    const successElement = document.getElementById(elementId);
    if (successElement) {
        successElement.textContent = message;
        successElement.classList.remove('d-none');
    }
}

// Hide element
function hideElement(elementId) {
    const element = document.getElementById(elementId);
    if (element) {
        element.classList.add('d-none');
    }
}

// Format date
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
    });
}

// Format currency
function formatCurrency(amount) {
    return '₹' + amount.toLocaleString('en-IN');
}

/* ========================================
   NAVIGATION FUNCTIONS
   ======================================== */

// Show rent items page
function showRentItems() {
    const currentUser = getCurrentUser();
    if (!currentUser) {
        const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
    } else {
        window.location.href = 'rent-items.html';
    }
}

// Show list item page
function showListItem() {
    const currentUser = getCurrentUser();
    if (!currentUser) {
        const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
    } else {
        window.location.href = 'dashboard.html';
    }
}

// Browse items by category
function browseCategory(category) {
    const currentUser = getCurrentUser();
    if (!currentUser) {
        const loginModal = new bootstrap.Modal(document.getElementById('loginModal'));
        loginModal.show();
    } else {
        // Store selected category and redirect
        sessionStorage.setItem('selectedCategory', category);
        window.location.href = 'rent-items.html';
    }
}
