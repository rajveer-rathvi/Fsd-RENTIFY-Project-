/* ========================================
   RENTIFY - Reviews System
   Handles user reviews and ratings
   ======================================== */

// Initialize reviews on page load
document.addEventListener('DOMContentLoaded', function() {
    if (document.getElementById('reviewsContainer')) {
        loadReviews();
        setupReviewForm();
        updateReviewStats();
        
        // Show write review card if user is logged in
        const currentUser = getCurrentUser();
        if (currentUser) {
            document.getElementById('writeReviewCard').style.display = 'block';
        }
    }
});

/* ========================================
   REVIEW RATING STARS
   ======================================== */

let selectedRating = 0;

function setupReviewForm() {
    // Rating stars interaction
    const stars = document.querySelectorAll('.rating-star');
    stars.forEach(star => {
        star.addEventListener('click', function() {
            selectedRating = parseInt(this.getAttribute('data-rating'));
            document.getElementById('reviewRating').value = selectedRating;
            updateStarDisplay(selectedRating);
        });
        
        star.addEventListener('mouseenter', function() {
            const rating = parseInt(this.getAttribute('data-rating'));
            updateStarDisplay(rating);
        });
    });
    
    // Reset stars on mouse leave
    document.querySelector('.rating-input').addEventListener('mouseleave', function() {
        updateStarDisplay(selectedRating);
    });
    
    // Review form submission
    const reviewForm = document.getElementById('reviewForm');
    if (reviewForm) {
        reviewForm.addEventListener('submit', handleReviewSubmit);
    }
}

function updateStarDisplay(rating) {
    const stars = document.querySelectorAll('.rating-star');
    stars.forEach((star, index) => {
        if (index < rating) {
            star.classList.remove('bi-star');
            star.classList.add('bi-star-fill', 'text-warning');
        } else {
            star.classList.remove('bi-star-fill', 'text-warning');
            star.classList.add('bi-star');
        }
    });
}

/* ========================================
   SUBMIT REVIEW
   ======================================== */

function handleReviewSubmit(e) {
    e.preventDefault();
    
    const currentUser = getCurrentUser();
    if (!currentUser) {
        alert('Please login to submit a review');
        return;
    }
    
    const rating = parseInt(document.getElementById('reviewRating').value);
    const text = document.getElementById('reviewText').value.trim();
    
    if (!rating || rating < 1 || rating > 5) {
        alert('Please select a rating');
        return;
    }
    
    if (!text || text.length < 10) {
        alert('Please write at least 10 characters');
        return;
    }
    
    // Create review object
    const review = {
        id: generateId(),
        userId: currentUser.id,
        userName: currentUser.name,
        rating: rating,
        text: text,
        createdAt: new Date().toISOString()
    };
    
    // Save review
    const reviews = getReviews();
    reviews.push(review);
    localStorage.setItem('rentify_reviews', JSON.stringify(reviews));
    
    // Reset form
    document.getElementById('reviewForm').reset();
    selectedRating = 0;
    updateStarDisplay(0);
    
    // Reload reviews
    loadReviews();
    updateReviewStats();
    
    alert('Thank you for your review!');
}

/* ========================================
   LOAD AND DISPLAY REVIEWS
   ======================================== */

function loadReviews() {
    const reviews = getReviews();
    const container = document.getElementById('reviewsContainer');
    const noReviews = document.getElementById('noReviews');
    
    if (reviews.length === 0) {
        container.innerHTML = '';
        noReviews.style.display = 'block';
        return;
    }
    
    noReviews.style.display = 'none';
    
    // Sort by date (newest first)
    reviews.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Display reviews
    container.innerHTML = reviews.map(review => `
        <div class="col-md-6">
            <div class="card h-100">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <div>
                            <h6 class="mb-0">${review.userName}</h6>
                            <small class="text-muted">${formatDate(review.createdAt)}</small>
                        </div>
                        <div class="text-warning">
                            ${generateStars(review.rating)}
                        </div>
                    </div>
                    <p class="card-text">${review.text}</p>
                </div>
            </div>
        </div>
    `).join('');
}

function generateStars(rating) {
    let stars = '';
    for (let i = 1; i <= 5; i++) {
        if (i <= rating) {
            stars += '<i class="bi bi-star-fill"></i>';
        } else {
            stars += '<i class="bi bi-star"></i>';
        }
    }
    return stars;
}

/* ========================================
   UPDATE REVIEW STATISTICS
   ======================================== */

function updateReviewStats() {
    const reviews = getReviews();
    const totalReviews = reviews.length;
    
    document.getElementById('totalReviews').textContent = totalReviews;
    
    if (totalReviews > 0) {
        const avgRating = reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews;
        document.getElementById('avgRating').textContent = avgRating.toFixed(1);
    }
}

/* ========================================
   GET REVIEWS FROM LOCALSTORAGE
   ======================================== */

function getReviews() {
    return JSON.parse(localStorage.getItem('rentify_reviews') || '[]');
}
