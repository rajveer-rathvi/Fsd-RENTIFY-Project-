/* ========================================
   RENTIFY - Sample Data for Testing
   Copy and paste this in browser console (F12)
   to populate the application with test data
   ======================================== */

// INSTRUCTIONS:
// 1. Open index.html in browser
// 2. Press F12 to open Developer Console
// 3. Copy this entire file content
// 4. Paste in console and press Enter
// 5. Refresh the page
// 6. Login with provided credentials

console.log('🚀 Loading RENTIFY sample data...');

// Clear existing data
localStorage.clear();

// Sample Users
const sampleUsers = [
    {
        id: "user_001_alice",
        name: "Alice Johnson",
        email: "alice@test.com",
        password: btoa("alice123"), // Password: alice123
        phone: "9876543210",
        createdAt: "2024-01-10T10:00:00.000Z"
    },
    {
        id: "user_002_bob",
        name: "Bob Smith",
        email: "bob@test.com",
        password: btoa("bob123"), // Password: bob123
        phone: "9876543211",
        createdAt: "2024-01-11T10:00:00.000Z"
    },
    {
        id: "user_003_carol",
        name: "Carol Williams",
        email: "carol@test.com",
        password: btoa("carol123"), // Password: carol123
        phone: "9876543212",
        createdAt: "2024-01-12T10:00:00.000Z"
    }
];

// Sample Items - Electronics
const electronicsItems = [
    {
        id: "item_001_laptop",
        name: "MacBook Pro 16-inch",
        category: "Electronics",
        price: 1000,
        description: "M1 Pro chip, 16GB RAM, 512GB SSD. Perfect for development and creative work.",
        image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400",
        ownerId: "user_001_alice",
        ownerName: "Alice Johnson",
        ownerPhone: "9876543210",
        status: "available",
        createdAt: "2024-01-13T10:00:00.000Z"
    },
    {
        id: "item_002_ipad",
        name: "iPad Pro 12.9-inch",
        category: "Electronics",
        price: 500,
        description: "Latest model with Apple Pencil. Great for digital art and note-taking.",
        image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=400",
        ownerId: "user_002_bob",
        ownerName: "Bob Smith",
        ownerPhone: "9876543211",
        status: "available",
        createdAt: "2024-01-13T11:00:00.000Z"
    },
    {
        id: "item_003_gaming",
        name: "Gaming Console PS5",
        category: "Electronics",
        price: 300,
        description: "PlayStation 5 with 2 controllers and 5 games included.",
        image: "https://images.unsplash.com/photo-1606144042614-b2417e99c4e3?w=400",
        ownerId: "user_003_carol",
        ownerName: "Carol Williams",
        ownerPhone: "9876543212",
        status: "available",
        createdAt: "2024-01-13T12:00:00.000Z"
    }
];

// Sample Items - Cameras
const cameraItems = [
    {
        id: "item_004_dslr",
        name: "Canon EOS 5D Mark IV",
        category: "Cameras",
        price: 500,
        description: "Professional DSLR camera with 24-70mm lens. Perfect for photography enthusiasts.",
        image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400",
        ownerId: "user_001_alice",
        ownerName: "Alice Johnson",
        ownerPhone: "9876543210",
        status: "available",
        createdAt: "2024-01-14T10:00:00.000Z"
    },
    {
        id: "item_005_mirrorless",
        name: "Sony A7 III Mirrorless",
        category: "Cameras",
        price: 600,
        description: "Full-frame mirrorless camera with 28-70mm lens. Excellent for video.",
        image: "https://images.unsplash.com/photo-1606980707146-b3a0c2c8c6e4?w=400",
        ownerId: "user_002_bob",
        ownerName: "Bob Smith",
        ownerPhone: "9876543211",
        status: "available",
        createdAt: "2024-01-14T11:00:00.000Z"
    },
    {
        id: "item_006_gopro",
        name: "GoPro Hero 11 Black",
        category: "Cameras",
        price: 200,
        description: "Action camera with 5.3K video. Perfect for adventure sports.",
        image: "https://images.unsplash.com/photo-1519638399535-1b036603ac77?w=400",
        ownerId: "user_003_carol",
        ownerName: "Carol Williams",
        ownerPhone: "9876543212",
        status: "available",
        createdAt: "2024-01-14T12:00:00.000Z"
    }
];

// Sample Items - Tools
const toolItems = [
    {
        id: "item_007_drill",
        name: "Professional Power Drill Set",
        category: "Tools",
        price: 100,
        description: "Cordless drill with 50+ accessories. Perfect for home improvement.",
        image: "https://images.unsplash.com/photo-1530124566582-a618bc2615dc?w=400",
        ownerId: "user_001_alice",
        ownerName: "Alice Johnson",
        ownerPhone: "9876543210",
        status: "available",
        createdAt: "2024-01-15T10:00:00.000Z"
    },
    {
        id: "item_008_toolbox",
        name: "Complete Tool Box Kit",
        category: "Tools",
        price: 150,
        description: "200+ piece tool set with carrying case. Everything you need for repairs.",
        image: "https://images.unsplash.com/photo-1572981779307-38b8cabb2407?w=400",
        ownerId: "user_002_bob",
        ownerName: "Bob Smith",
        ownerPhone: "9876543211",
        status: "available",
        createdAt: "2024-01-15T11:00:00.000Z"
    }
];

// Sample Items - Vehicles
const vehicleItems = [
    {
        id: "item_009_bike",
        name: "Mountain Bike - Trek X-Caliber",
        category: "Vehicles",
        price: 300,
        description: "21-speed mountain bike. Perfect for trails and city riding.",
        image: "https://images.unsplash.com/photo-1571188654248-7a89213915f7?w=400",
        ownerId: "user_001_alice",
        ownerName: "Alice Johnson",
        ownerPhone: "9876543210",
        status: "available",
        createdAt: "2024-01-16T10:00:00.000Z"
    },
    {
        id: "item_010_scooter",
        name: "Electric Scooter",
        category: "Vehicles",
        price: 200,
        description: "Electric scooter with 40km range. Eco-friendly city transport.",
        image: "https://images.unsplash.com/photo-1558981806-ec527fa84c39?w=400",
        ownerId: "user_003_carol",
        ownerName: "Carol Williams",
        ownerPhone: "9876543212",
        status: "available",
        createdAt: "2024-01-16T11:00:00.000Z"
    }
];

// Sample Items - Sports
const sportsItems = [
    {
        id: "item_011_tennis",
        name: "Tennis Racket Set",
        category: "Sports",
        price: 80,
        description: "Professional tennis racket with balls and bag. Ready to play!",
        image: "https://images.unsplash.com/photo-1519505907962-0a6cb0167c73?w=400",
        ownerId: "user_002_bob",
        ownerName: "Bob Smith",
        ownerPhone: "9876543211",
        status: "available",
        createdAt: "2024-01-17T10:00:00.000Z"
    },
    {
        id: "item_012_camping",
        name: "Camping Tent - 4 Person",
        category: "Sports",
        price: 150,
        description: "Waterproof camping tent with sleeping bags. Perfect for outdoor adventures.",
        image: "https://images.unsplash.com/photo-1478131143081-80f7f84ca84d?w=400",
        ownerId: "user_003_carol",
        ownerName: "Carol Williams",
        ownerPhone: "9876543212",
        status: "available",
        createdAt: "2024-01-17T11:00:00.000Z"
    }
];

// Sample Items - Furniture
const furnitureItems = [
    {
        id: "item_013_projector",
        name: "Home Theater Projector",
        category: "Furniture",
        price: 400,
        description: "4K projector with 120-inch screen. Perfect for movie nights.",
        image: "https://images.unsplash.com/photo-1593784991095-a205069470b6?w=400",
        ownerId: "user_001_alice",
        ownerName: "Alice Johnson",
        ownerPhone: "9876543210",
        status: "available",
        createdAt: "2024-01-18T10:00:00.000Z"
    }
];

// Combine all items
const allItems = [
    ...electronicsItems,
    ...cameraItems,
    ...toolItems,
    ...vehicleItems,
    ...sportsItems,
    ...furnitureItems
];

// Sample Rentals (Bob rented from Alice)
const sampleRentals = [
    {
        id: "rental_001",
        itemId: "item_004_dslr",
        itemName: "Canon EOS 5D Mark IV",
        itemCategory: "Cameras",
        itemDescription: "Professional DSLR camera with 24-70mm lens. Perfect for photography enthusiasts.",
        itemImage: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400",
        renterId: "user_002_bob",
        renterName: "Bob Smith",
        ownerId: "user_001_alice",
        ownerName: "Alice Johnson",
        ownerPhone: "9876543210",
        price: 500,
        rentDate: "2024-01-19T10:00:00.000Z"
    }
];

// Update rented item status
const itemToRent = allItems.find(item => item.id === "item_004_dslr");
if (itemToRent) {
    itemToRent.status = "rented";
}

// Save to LocalStorage
try {
    localStorage.setItem('rentify_users', JSON.stringify(sampleUsers));
    localStorage.setItem('rentify_items', JSON.stringify(allItems));
    localStorage.setItem('rentify_rentals', JSON.stringify(sampleRentals));
    
    console.log('✅ Sample data loaded successfully!');
    console.log('');
    console.log('📊 Data Summary:');
    console.log('   Users: ' + sampleUsers.length);
    console.log('   Items: ' + allItems.length);
    console.log('   Rentals: ' + sampleRentals.length);
    console.log('');
    console.log('🔐 Login Credentials:');
    console.log('   User 1: alice@test.com / alice123');
    console.log('   User 2: bob@test.com / bob123');
    console.log('   User 3: carol@test.com / carol123');
    console.log('');
    console.log('📦 Items by Category:');
    console.log('   Electronics: ' + electronicsItems.length);
    console.log('   Cameras: ' + cameraItems.length);
    console.log('   Tools: ' + toolItems.length);
    console.log('   Vehicles: ' + vehicleItems.length);
    console.log('   Sports: ' + sportsItems.length);
    console.log('   Furniture: ' + furnitureItems.length);
    console.log('');
    console.log('🎯 Quick Test Scenarios:');
    console.log('   1. Login as Alice - See 4 items listed, 0 rentals');
    console.log('   2. Login as Bob - See 3 items listed, 1 rental (Canon camera)');
    console.log('   3. Login as Carol - See 3 items listed, 0 rentals');
    console.log('   4. Browse items - See 12 available items (1 is rented)');
    console.log('   5. Test search - Try "camera", "bike", "laptop"');
    console.log('   6. Test filter - Select different categories');
    console.log('');
    console.log('🔄 Refreshing page in 2 seconds...');
    
    setTimeout(() => {
        location.reload();
    }, 2000);
    
} catch (error) {
    console.error('❌ Error loading sample data:', error);
    console.log('Please check if LocalStorage is enabled in your browser.');
}

/* ========================================
   ALTERNATIVE: Minimal Test Data
   Use this if you want just 2 users and 2 items
   ======================================== */

function loadMinimalData() {
    localStorage.clear();
    
    const minimalUsers = [
        {
            id: "user_min_001",
            name: "Test User 1",
            email: "test1@example.com",
            password: btoa("test123"),
            phone: "1234567890",
            createdAt: new Date().toISOString()
        },
        {
            id: "user_min_002",
            name: "Test User 2",
            email: "test2@example.com",
            password: btoa("test123"),
            phone: "1234567891",
            createdAt: new Date().toISOString()
        }
    ];
    
    const minimalItems = [
        {
            id: "item_min_001",
            name: "Test Camera",
            category: "Cameras",
            price: 100,
            description: "Test camera for demo",
            image: "https://images.unsplash.com/photo-1502920917128-1aa500764cbd?w=400",
            ownerId: "user_min_001",
            ownerName: "Test User 1",
            ownerPhone: "1234567890",
            status: "available",
            createdAt: new Date().toISOString()
        },
        {
            id: "item_min_002",
            name: "Test Laptop",
            category: "Electronics",
            price: 200,
            description: "Test laptop for demo",
            image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=400",
            ownerId: "user_min_002",
            ownerName: "Test User 2",
            ownerPhone: "1234567891",
            status: "available",
            createdAt: new Date().toISOString()
        }
    ];
    
    localStorage.setItem('rentify_users', JSON.stringify(minimalUsers));
    localStorage.setItem('rentify_items', JSON.stringify(minimalItems));
    localStorage.setItem('rentify_rentals', JSON.stringify([]));
    
    console.log('✅ Minimal test data loaded!');
    console.log('Login: test1@example.com / test123');
    console.log('Or: test2@example.com / test123');
    
    setTimeout(() => location.reload(), 2000);
}

// Uncomment the line below to load minimal data instead
// loadMinimalData();

/* ========================================
   CLEAR ALL DATA
   Use this to reset everything
   ======================================== */

function clearAllData() {
    localStorage.clear();
    console.log('✅ All data cleared!');
    console.log('Refreshing page...');
    setTimeout(() => location.reload(), 1000);
}

// Uncomment the line below to clear all data
// clearAllData();

/* ========================================
   VIEW CURRENT DATA
   Use this to see what's in LocalStorage
   ======================================== */

function viewCurrentData() {
    console.log('📊 Current LocalStorage Data:');
    console.log('');
    console.log('Users:', JSON.parse(localStorage.getItem('rentify_users') || '[]'));
    console.log('Items:', JSON.parse(localStorage.getItem('rentify_items') || '[]'));
    console.log('Rentals:', JSON.parse(localStorage.getItem('rentify_rentals') || '[]'));
    console.log('Current User:', JSON.parse(localStorage.getItem('rentify_currentUser') || 'null'));
}

// Uncomment the line below to view current data
// viewCurrentData();
